export const PLAYER_SCRIPT_URL =
  "https://megacloud.club/js/player/a/e1-player.min.js";
