export const PLAYER_SCRIPT_URL =
  "https://rapid-cloud.co/js/player/prod/e6-player-v2.min.js";
