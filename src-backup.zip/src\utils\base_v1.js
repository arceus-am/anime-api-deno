export const v1_base_url = "hianime.do";
