export const provider = "https://megacloud.club";
